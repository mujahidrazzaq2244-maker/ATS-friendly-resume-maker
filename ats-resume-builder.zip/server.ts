import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

// Standard lazy initialization of GoogleGenAI as recommended by the guidelines
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is required');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health and verification check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // End point: Score Resume
  app.post('/api/resume/score', async (req, res) => {
    try {
      const resumeData = req.body;
      const ai = getGeminiClient();

      // Formulate expert HR feedback instruction prompt
      const prompt = `As an expert modern corporate Human Resources executive and Applicant Tracking System (ATS) optimization specialist, carefully evaluate this candidate's resume payload. 

Candidate Name: ${resumeData.name}
Title: ${resumeData.title}
Summary Draft: ${resumeData.summary}

Education Details:
${JSON.stringify(resumeData.education)}

Professional Experience:
${JSON.stringify(resumeData.experience)}

Skills Listed:
${JSON.stringify(resumeData.skills)}

Certifications:
${JSON.stringify(resumeData.certifications)}

Provide a strict, professional ATS-friendly evaluation. Focus on:
1. Impact-oriented formulation (STAR method - Situation, Task, Action, Result). Are there real numbers or metric results?
2. Formatting and sections (Any missing sections or bad alignment?).
3. Technical and industry skills coverage (suggest missing high-demand target keywords based on their skills and role).
4. Clarity and brevity.

Output your feedback exactly matching the requested JSON schema. Be highly constructive, exact, and offer professional HR guidance. Do not use flowery or dramatic language.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: {
                type: Type.INTEGER,
                description: 'An integer score from 0 to 100 capturing the quality, impact, metric usage, and ATS suitability.'
              },
              rating: {
                type: Type.STRING,
                description: 'Brief overall rating rating: Needs Improvement, Good, or Excellent'
              },
              strengths: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'List of 2 to 4 positive, distinct aspects of the candidate’s resume representation.'
              },
              improvements: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'List of 2 to 4 tactical improvements (e.g. "Add metric value for LaunchPad experience").'
              },
              atsKeywords: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'List of recommended high-impact industry terms/keywords corresponding to their expertise that are often scanned.'
              },
              metricsCheck: {
                type: Type.STRING,
                description: 'A 1-2 sentence diagnostic specifically addressing whether they used metrics/numbers correctly in their achievements.'
              }
            },
            required: ['score', 'rating', 'strengths', 'improvements', 'atsKeywords', 'metricsCheck']
          }
        }
      });

      const resultText = response.text || '{}';
      res.json(JSON.parse(resultText.trim()));
    } catch (error: any) {
      console.error('Error scoring resume:', error);
      res.status(500).json({ error: error.message || 'Error occurred while contacting expert AI HR services.' });
    }
  });

  // End point: Improve Profile Summary
  app.post('/api/resume/improve-summary', async (req, res) => {
    try {
      const { summary, title, skills } = req.body;
      const ai = getGeminiClient();

      const prompt = `As an expert executive HR manager, rewrite this candidate's profile summary to be highly professional, impactful, and optimized for applicant tracking systems. It must be strong, action-oriented, and directly address their primary expertise.
      
      Current Title: ${title || 'Professional'}
      Current Draft: ${summary || 'None'}
      Highlighted Skills: ${skills ? skills.join(', ') : 'None'}
      
      Format the output as a clean paragraph of 3-4 sentences. Start with a strong statement of years of experience or expertise, highlight 1 or 2 core accomplishments or high-impact technical skills, and state the value they deliver to an organization. Ensure there are no placeholder texts (like [insert number]). Maintain a professional, executive tone.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt
      });

      const improved = response.text?.trim() || '';
      res.json({ improved });
    } catch (error: any) {
      console.error('Error improving summary:', error);
      res.status(500).json({ error: error.message || 'Error communicating with AI optimizer' });
    }
  });

  // End point: Refine / STAR-format Experience Bullet
  app.post('/api/resume/refine-bullet', async (req, res) => {
    try {
      const { bullet, position, company } = req.body;
      const ai = getGeminiClient();

      const prompt = `As an expert HR recruitment consultant, rewrite this single, dry resume bullet point to make it highly achievements-oriented and ATS-friendly. It should start with a strong action verb, describe the business problem/situation, the action taken, and quantify a plausible business result (quantified with a metric/percentage to make it standard for top-tier corporate resumes).
      
      Role: ${position || 'Specialist'} at ${company || 'Organization'}
      Draft Bullet: "${bullet}"
      
      Provide exactly 1 optimized bullet point. Do not add comments, preambles, or multiple options. It must be direct, clean, and ready to paste into the resume.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt
      });

      const optimized = response.text?.trim().replace(/^-\s*/, '') || '';
      res.json({ optimized });
    } catch (error: any) {
      console.error('Error refining bullet:', error);
      res.status(500).json({ error: error.message || 'Error communicating with AI optimizer' });
    }
  });

  // Vite middleware setup for static assets and hot module replacement
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
