import React, { useState } from 'react';
import { ResumeData, Education, Experience, Certifications } from '../types';
import { 
  Plus, 
  Trash2, 
  Sparkles, 
  Briefcase, 
  GraduationCap, 
  Wrench, 
  Award, 
  User, 
  Globe, 
  Linkedin, 
  Github, 
  Mail, 
  Phone, 
  MapPin,
  ChevronDown,
  ChevronUp,
  Loader2
} from 'lucide-react';

interface ResumeFormProps {
  data: ResumeData;
  onChange: (newData: ResumeData) => void;
  onImproveSummary: (currentSummary: string) => Promise<void>;
  onRefineBullet: (index: number, bulletIndex: number, currentBullet: string, position: string, company: string) => Promise<void>;
  loadingSummary: boolean;
  loadingBulletId: string | null; // "expIndex-bulletIndex" or null
}

export default function ResumeForm({ 
  data, 
  onChange, 
  onImproveSummary, 
  onRefineBullet,
  loadingSummary,
  loadingBulletId
}: ResumeFormProps) {
  const [activeSection, setActiveSection] = useState<'contact' | 'summary' | 'experience' | 'skills' | 'education' | 'certifications'>('contact');
  const [newSkill, setNewSkill] = useState('');

  // Handle simple field change
  const handleChange = (field: keyof ResumeData, value: any) => {
    onChange({ ...data, [field]: value });
  };

  // Toggle sections
  const sections = [
    { id: 'contact', label: 'Contact & Heading', icon: User },
    { id: 'summary', label: 'Profile Summary', icon: Sparkles },
    { id: 'experience', label: 'Work Experience', icon: Briefcase },
    { id: 'skills', label: 'Competencies & Skills', icon: Wrench },
    { id: 'education', label: 'Education History', icon: GraduationCap },
    { id: 'certifications', label: 'Certifications', icon: Award },
  ] as const;

  // --- EXPERIENCE LOGIC ---
  const addExperience = () => {
    const newExp: Experience = {
      id: `exp-${Date.now()}`,
      company: '',
      position: '',
      startDate: '',
      endDate: '',
      location: '',
      isCurrent: false,
      bullets: ['']
    };
    handleChange('experience', [...data.experience, newExp]);
  };

  const updateExperience = (index: number, field: keyof Experience, value: any) => {
    const updated = [...data.experience];
    updated[index] = { ...updated[index], [field]: value };
    handleChange('experience', updated);
  };

  const removeExperience = (index: number) => {
    const updated = data.experience.filter((_, i) => i !== index);
    handleChange('experience', updated);
  };

  const addExperienceBullet = (expIndex: number) => {
    const updated = [...data.experience];
    updated[expIndex].bullets = [...updated[expIndex].bullets, ''];
    handleChange('experience', updated);
  };

  const updateExperienceBullet = (expIndex: number, bulletIndex: number, value: string) => {
    const updated = [...data.experience];
    const bullets = [...updated[expIndex].bullets];
    bullets[bulletIndex] = value;
    updated[expIndex].bullets = bullets;
    handleChange('experience', updated);
  };

  const removeExperienceBullet = (expIndex: number, bulletIndex: number) => {
    const updated = [...data.experience];
    updated[expIndex].bullets = updated[expIndex].bullets.filter((_, idx) => idx !== bulletIndex);
    handleChange('experience', updated);
  };

  // --- EDUCATION LOGIC ---
  const addEducation = () => {
    const newEdu: Education = {
      id: `edu-${Date.now()}`,
      institution: '',
      degree: '',
      fieldOfStudy: '',
      startDate: '',
      endDate: '',
      location: '',
      gpa: '',
      description: ''
    };
    handleChange('education', [...data.education, newEdu]);
  };

  const updateEducation = (index: number, field: keyof Education, value: any) => {
    const updated = [...data.education];
    updated[index] = { ...updated[index], [field]: value };
    handleChange('education', updated);
  };

  const removeEducation = (index: number) => {
    const updated = data.education.filter((_, i) => i !== index);
    handleChange('education', updated);
  };

  // --- CERTIFICATION LOGIC ---
  const addCertification = () => {
    const newCert: Certifications = {
      id: `cert-${Date.now()}`,
      name: '',
      issuer: '',
      date: ''
    };
    handleChange('certifications', [...data.certifications, newCert]);
  };

  const updateCertification = (index: number, field: keyof Certifications, value: any) => {
    const updated = [...data.certifications];
    updated[index] = { ...updated[index], [field]: value };
    handleChange('certifications', updated);
  };

  const removeCertification = (index: number) => {
    const updated = data.certifications.filter((_, i) => i !== index);
    handleChange('certifications', updated);
  };

  // --- SKILLS LOGIC ---
  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newSkill.trim();
    if (trimmed && !data.skills.includes(trimmed)) {
      handleChange('skills', [...data.skills, trimmed]);
      setNewSkill('');
    }
  };

  const removeSkill = (skillToRemove: string) => {
    handleChange('skills', data.skills.filter(s => s !== skillToRemove));
  };

  const addPopularSkill = (skill: string) => {
    if (!data.skills.includes(skill)) {
      handleChange('skills', [...data.skills, skill]);
    }
  };

  const popularSkills = [
    'React', 'TypeScript', 'Node.js', 'SQL', 'PostgreSQL', 'Project Management', 
    'Agile Methodology', 'Strategic Planning', 'SEO / SEM', 'Data Analysis', 
    'Budgeting', 'Public Relations', 'Customer Experience', 'Leadership', 'Negotiation'
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-stone-100 divide-y divide-stone-100 overflow-hidden" id="editor-form-root">
      
      {/* 1. Header with quick sections tab navigation */}
      <div className="p-4 bg-stone-50 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-2">
        {sections.map((sec) => {
          const Icon = sec.icon;
          const isActive = activeSection === sec.id;
          return (
            <button
              key={sec.id}
              onClick={() => setActiveSection(sec.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                isActive 
                  ? 'bg-amber-600 text-white shadow-sm' 
                  : 'bg-white text-stone-600 hover:text-stone-900 border border-stone-200'
              }`}
            >
              <Icon size={14} />
              {sec.label}
            </button>
          );
        })}
      </div>

      {/* 2. Active Section Editor */}
      <div className="p-6">
        
        {/* CONTACT SECTION */}
        {activeSection === 'contact' && (
          <div className="space-y-4" id="section-editor-contact">
            <h3 className="text-lg font-bold text-stone-900 mb-2">Primary Contact Info</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="text"
                    value={data.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    placeholder="e.g. Sarah Jenkins"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">Target Professional Title</label>
                <div className="relative">
                  <Briefcase className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="text"
                    value={data.title}
                    onChange={(e) => handleChange('title', e.target.value)}
                    placeholder="e.g. Senior Software Engineer"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="email"
                    value={data.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    placeholder="e.g. sarah.jenkins@email.com"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="text"
                    value={data.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    placeholder="e.g. (555) 123-4567"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="text"
                    value={data.location}
                    onChange={(e) => handleChange('location', e.target.value)}
                    placeholder="e.g. San Francisco, CA"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">Portfolio or Website</label>
                <div className="relative">
                  <Globe className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="text"
                    value={data.website}
                    onChange={(e) => handleChange('website', e.target.value)}
                    placeholder="e.g. https://yourwebsite.dev"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">LinkedIn Profile</label>
                <div className="relative">
                  <Linkedin className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="text"
                    value={data.linkedin}
                    onChange={(e) => handleChange('linkedin', e.target.value)}
                    placeholder="e.g. https://linkedin.com/in/username"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">GitHub Username</label>
                <div className="relative">
                  <Github className="absolute left-3 top-3.5 text-stone-400" size={16} />
                  <input
                    type="text"
                    value={data.github}
                    onChange={(e) => handleChange('github', e.target.value)}
                    placeholder="e.g. https://github.com/username"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                </div>
              </div>
            </div>
            
            <p className="text-xs text-stone-400 mt-4 leading-relaxed italic border-t border-stone-100 pt-3">
              * Note: For strict ATS-compatibility, use plain text characters without embedded symbols, icons, or text structures. Full-URL references are standard.
            </p>
          </div>
        )}

        {/* PROFILE SUMMARY SECTION */}
        {activeSection === 'summary' && (
          <div className="space-y-4" id="section-editor-summary">
            <div className="flex justify-between items-center mb-1">
              <h3 className="text-lg font-bold text-stone-900">Professional Summary</h3>
              <button
                type="button"
                disabled={loadingSummary}
                onClick={() => onImproveSummary(data.summary)}
                className="flex items-center gap-1 text-xs text-amber-700 bg-amber-50 hover:bg-amber-100 hover:text-amber-800 py-1.5 px-3 rounded-lg font-semibold transition-colors disabled:opacity-60 cursor-pointer"
              >
                {loadingSummary ? (
                  <>
                    <Loader2 className="animate-spin" size={13} />
                    HR Polishing...
                  </>
                ) : (
                  <>
                    <Sparkles size={13} />
                    AI Polish Summary
                  </>
                )}
              </button>
            </div>
            
            <p className="text-xs text-stone-500 leading-relaxed mb-2">
              Provide a professional overview highlighting your years of experience, unique skills, and maximum quantitative achievements. The AI HR Coach can automatically rewrite or polish this summary into an optimal ATS keyword pattern.
            </p>

            <textarea
              rows={6}
              value={data.summary}
              onChange={(e) => handleChange('summary', e.target.value)}
              placeholder="Driven corporate professional with 5+ years of experience leading..."
              className="w-full p-3 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white leading-relaxed resize-y"
            />
            
            <div className="flex justify-between text-xs text-stone-400">
              <span>{data.summary ? data.summary.split(/\s+/).filter(Boolean).length : 0} words</span>
              <span>{data.summary ? data.summary.length : 0} characters</span>
            </div>
          </div>
        )}

        {/* WORK EXPERIENCE SECTION */}
        {activeSection === 'experience' && (
          <div className="space-y-6" id="section-editor-experience">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold text-stone-900">Work Experience</h3>
              <button
                type="button"
                onClick={addExperience}
                className="flex items-center gap-1 text-xs text-white bg-amber-600 hover:bg-amber-700 py-1.5 px-3 rounded-lg font-semibold transition-all shadow-sm cursor-pointer"
              >
                <Plus size={14} />
                Add Work History
              </button>
            </div>

            {data.experience.length === 0 ? (
              <div className="text-center py-10 bg-stone-50 rounded-xl border border-dashed border-stone-200">
                <Briefcase className="mx-auto text-stone-400 mb-2" size={32} />
                <p className="text-sm text-stone-500">No work experiences listed yet.</p>
                <button
                  onClick={addExperience}
                  className="text-xs text-amber-600 font-bold mt-2 hover:underline cursor-pointer"
                >
                  Click to add your first work history.
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {data.experience.map((exp, expIdx) => (
                  <div key={exp.id} className="relative p-5 border border-stone-200 rounded-xl bg-stone-50/50 space-y-4">
                    
                    <button
                      type="button"
                      onClick={() => removeExperience(expIdx)}
                      className="absolute top-4 right-4 text-stone-400 hover:text-red-500 transition-colors cursor-pointer"
                      title="Delete Experience"
                    >
                      <Trash2 size={16} />
                    </button>

                    <div className="font-semibold text-sm text-stone-700 border-b border-stone-100 pb-1 mr-6">
                      Role #{expIdx + 1}: {exp.position || '(Untitled Position)'}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Company / Organization</label>
                        <input
                          type="text"
                          value={exp.company}
                          onChange={(e) => updateExperience(expIdx, 'company', e.target.value)}
                          placeholder="e.g. CloudScale Technologies"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Job Title</label>
                        <input
                          type="text"
                          value={exp.position}
                          onChange={(e) => updateExperience(expIdx, 'position', e.target.value)}
                          placeholder="e.g. Senior Software Engineer"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Location</label>
                        <input
                          type="text"
                          value={exp.location}
                          onChange={(e) => updateExperience(expIdx, 'location', e.target.value)}
                          placeholder="e.g. San Francisco, CA"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-xs font-semibold text-stone-500 mb-1">START DATE</label>
                          <input
                            type="month"
                            value={exp.startDate}
                            onChange={(e) => updateExperience(expIdx, 'startDate', e.target.value)}
                            className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-700 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-stone-500 mb-1">END DATE</label>
                          <input
                            type="month"
                            value={exp.endDate}
                            disabled={exp.isCurrent}
                            onChange={(e) => updateExperience(expIdx, 'endDate', e.target.value)}
                            className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-700 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 disabled:opacity-50"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 mt-1">
                      <input
                        type="checkbox"
                        id={`isCurrent-${exp.id}`}
                        checked={exp.isCurrent}
                        onChange={(e) => updateExperience(expIdx, 'isCurrent', e.target.checked)}
                        className="rounded border-stone-300 text-amber-600 focus:ring-amber-500"
                      />
                      <label htmlFor={`isCurrent-${exp.id}`} className="text-xs text-stone-600 font-medium cursor-pointer">
                        I am currently working in this role
                      </label>
                    </div>

                    {/* BULLET LIST ITEMS */}
                    <div className="space-y-3 pt-3 border-t border-stone-100">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-stone-600 uppercase tracking-wide">Key Achievements & Bullet Points</span>
                        <button
                          type="button"
                          onClick={() => addExperienceBullet(expIdx)}
                          className="text-amber-700 font-semibold text-xs flex items-center gap-0.5 hover:text-amber-800 cursor-pointer"
                        >
                          <Plus size={12} />
                          Add Bullet
                        </button>
                      </div>

                      <div className="space-y-2">
                        {exp.bullets.map((bullet, bulletIdx) => {
                          const currentBulletIdStr = `${expIdx}-${bulletIdx}`;
                          const isCustomLoading = loadingBulletId === currentBulletIdStr;

                          return (
                            <div key={bulletIdx} className="flex gap-2">
                              <span className="text-stone-400 text-xs mt-3 select-none">•</span>
                              <div className="flex-1 space-y-1">
                                <input
                                  type="text"
                                  value={bullet}
                                  onChange={(e) => updateExperienceBullet(expIdx, bulletIdx, e.target.value)}
                                  placeholder="Formulated and executed x program that achieved y..."
                                  className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                                />
                              </div>

                              <div className="flex gap-1 items-start mt-0.5">
                                <button
                                  type="button"
                                  disabled={loadingBulletId !== null || !bullet.trim()}
                                  onClick={() => onRefineBullet(expIdx, bulletIdx, bullet, exp.position, exp.company)}
                                  className="p-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 disabled:opacity-50 transition-colors shadow-sm cursor-pointer"
                                  title="AI HR STAR Polish: Rewrites your description to state Situation, Action, Results with metric metrics."
                                >
                                  {isCustomLoading ? (
                                    <Loader2 className="animate-spin text-amber-700" size={14} />
                                  ) : (
                                    <Sparkles size={14} />
                                  )}
                                </button>
                                
                                <button
                                  type="button"
                                  onClick={() => removeExperienceBullet(expIdx, bulletIdx)}
                                  className="p-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors shadow-sm cursor-pointer"
                                  title="Delete Bullet"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      
                      <div className="bg-amber-50/50 p-2 text-[11px] text-amber-800 leading-normal rounded-lg border border-amber-100/50">
                        <strong>Expert HR TIP:</strong> Hit <strong><Sparkles className="inline" size={10} /></strong> to convert lazy descriptions (e.g. "managed database") into high impact quantified metric statements (e.g. "managed 15 PostgreSQL systems, optimizing indexes to decrease query cycles from 12s down to 30ms").
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* COMPETENCIES & SKILLS SECTION */}
        {activeSection === 'skills' && (
          <div className="space-y-4" id="section-editor-skills">
            <h3 className="text-lg font-bold text-stone-900">Core Competencies & Skills</h3>
            <p className="text-xs text-stone-500 leading-relaxed">
              Tailor your skills directly to standard job descriptions. ATS scanners check for direct name matches under skills. Add custom keywords or select from the options list.
            </p>

            <form onSubmit={handleAddSkill} className="flex gap-2">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="e.g. SQL Optimization"
                className="flex-1 bg-stone-50 border border-stone-200 rounded-lg p-2.5 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
              />
              <button
                type="submit"
                className="bg-stone-900 text-white hover:bg-black px-4 rounded-lg text-sm font-bold shadow-sm transition-colors cursor-pointer"
              >
                Add Skill
              </button>
            </form>

            {data.skills.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {data.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="flex items-center gap-1 bg-amber-50 text-amber-900 border border-amber-200 px-2.5 py-1 rounded-full text-xs font-semibold"
                  >
                    {skill}
                    <button
                      type="button"
                      onClick={() => removeSkill(skill)}
                      className="text-amber-800 hover:text-amber-950 font-normal select-none relative ml-0.5"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}

            <div className="pt-3 border-t border-stone-100 space-y-2">
              <span className="block text-xs font-bold text-stone-500 uppercase tracking-wide">Popular & ATS-Friendly suggestions:</span>
              <div className="flex flex-wrap gap-1.5">
                {popularSkills.map((ps) => {
                  const isAlreadyAdded = data.skills.includes(ps);
                  return (
                    <button
                      key={ps}
                      type="button"
                      disabled={isAlreadyAdded}
                      onClick={() => addPopularSkill(ps)}
                      className={`text-xs px-2 py-1 rounded border transition-colors cursor-pointer ${
                        isAlreadyAdded 
                          ? 'bg-stone-50 text-stone-300 border-stone-100 cursor-not-allowed' 
                          : 'bg-white hover:bg-stone-50 text-stone-700 border-stone-200'
                      }`}
                    >
                      + {ps}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* EDUCATION HISTORY SECTION */}
        {activeSection === 'education' && (
          <div className="space-y-6" id="section-editor-education">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold text-stone-900">Education History</h3>
              <button
                type="button"
                onClick={addEducation}
                className="flex items-center gap-1 text-xs text-white bg-amber-600 hover:bg-amber-700 py-1.5 px-3 rounded-lg font-semibold transition-all shadow-sm cursor-pointer"
              >
                <Plus size={14} />
                Add Education
              </button>
            </div>

            {data.education.length === 0 ? (
              <div className="text-center py-10 bg-stone-50 rounded-xl border border-dashed border-stone-200">
                <GraduationCap className="mx-auto text-stone-400 mb-2" size={32} />
                <p className="text-sm text-stone-500">No education entries listed.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {data.education.map((edu, eduIdx) => (
                  <div key={edu.id} className="relative p-5 border border-stone-200 rounded-xl bg-stone-50/50 space-y-4">
                    
                    <button
                      type="button"
                      onClick={() => removeEducation(eduIdx)}
                      className="absolute top-4 right-4 text-stone-400 hover:text-red-500 transition-colors cursor-pointer"
                      title="Delete Education Entry"
                    >
                      <Trash2 size={16} />
                    </button>

                    <div className="font-semibold text-sm text-stone-700 border-b border-stone-100 pb-1 mr-6">
                      Degree #{eduIdx + 1}: {edu.degree || '(Untitled Degree)'}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Institution Name</label>
                        <input
                          type="text"
                          value={edu.institution}
                          onChange={(e) => updateEducation(eduIdx, 'institution', e.target.value)}
                          placeholder="e.g. University of Texas"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Degree Type</label>
                        <input
                          type="text"
                          value={edu.degree}
                          onChange={(e) => updateEducation(eduIdx, 'degree', e.target.value)}
                          placeholder="e.g. Bachelor of Business Administration"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Field of Study</label>
                        <input
                          type="text"
                          value={edu.fieldOfStudy}
                          onChange={(e) => updateEducation(eduIdx, 'fieldOfStudy', e.target.value)}
                          placeholder="e.g. Marketing"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Location</label>
                        <input
                          type="text"
                          value={edu.location}
                          onChange={(e) => updateEducation(eduIdx, 'location', e.target.value)}
                          placeholder="e.g. Austin, TX"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-xs font-semibold text-stone-500 mb-1">START YEAR</label>
                          <input
                            type="text"
                            value={edu.startDate}
                            onChange={(e) => updateEducation(eduIdx, 'startDate', e.target.value)}
                            placeholder="e.g. 2015"
                            className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-700 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-stone-500 mb-1">END YEAR</label>
                          <input
                            type="text"
                            value={edu.endDate}
                            onChange={(e) => updateEducation(eduIdx, 'endDate', e.target.value)}
                            placeholder="e.g. 2019"
                            className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-700 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">GPA / Score (Optional)</label>
                        <input
                          type="text"
                          value={edu.gpa}
                          onChange={(e) => updateEducation(eduIdx, 'gpa', e.target.value)}
                          placeholder="e.g. 3.82 / 4.0"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Additional description / Honors / Activities</label>
                      <textarea
                        rows={2}
                        value={edu.description}
                        onChange={(e) => updateEducation(eduIdx, 'description', e.target.value)}
                        placeholder="Honors: Beta Gamma Sigma Honor Society, Dean's List consecutive semesters..."
                        className="w-full bg-white border border-stone-200 rounded-lg p-3 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 resize-y whitespace-pre-wrap"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* CERTIFICATIONS SECTION */}
        {activeSection === 'certifications' && (
          <div className="space-y-6" id="section-editor-certifications">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold text-stone-900">Certifications</h3>
              <button
                type="button"
                onClick={addCertification}
                className="flex items-center gap-1 text-xs text-white bg-amber-600 hover:bg-amber-700 py-1.5 px-3 rounded-lg font-semibold transition-all shadow-sm cursor-pointer"
              >
                <Plus size={14} />
                Add Certification
              </button>
            </div>

            {data.certifications.length === 0 ? (
              <div className="text-center py-10 bg-stone-50 rounded-xl border border-dashed border-stone-200">
                <Award className="mx-auto text-stone-400 mb-2" size={32} />
                <p className="text-sm text-stone-500">No certifications listed.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {data.certifications.map((cert, certIdx) => (
                  <div key={cert.id} className="relative p-5 border border-stone-200 rounded-xl bg-stone-50/50 space-y-4">
                    
                    <button
                      type="button"
                      onClick={() => removeCertification(certIdx)}
                      className="absolute top-4 right-4 text-stone-400 hover:text-red-500 transition-colors cursor-pointer"
                      title="Delete Certification"
                    >
                      <Trash2 size={16} />
                    </button>

                    <div className="font-semibold text-sm text-stone-700 border-b border-stone-100 pb-1 mr-6">
                      Certification #{certIdx + 1}: {cert.name || '(Untitled Certification)'}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Certification Name</label>
                        <input
                          type="text"
                          value={cert.name}
                          onChange={(e) => updateCertification(certIdx, 'name', e.target.value)}
                          placeholder="e.g. AWS Certified Solutions Architect"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Issuing Organization</label>
                        <input
                          type="text"
                          value={cert.issuer}
                          onChange={(e) => updateCertification(certIdx, 'issuer', e.target.value)}
                          placeholder="e.g. Amazon Web Services"
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-800 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-500 uppercase mb-1">Date Issued (YYYY-MM)</label>
                        <input
                          type="month"
                          value={cert.date}
                          onChange={(e) => updateCertification(certIdx, 'date', e.target.value)}
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-700 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
