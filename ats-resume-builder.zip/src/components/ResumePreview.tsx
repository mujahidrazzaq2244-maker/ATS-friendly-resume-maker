import React from 'react';
import { ResumeData } from '../types';

interface ResumePreviewProps {
  data: ResumeData;
  theme: 'classic' | 'modern' | 'corporate' | 'tech';
}

export default function ResumePreview({ data, theme }: ResumePreviewProps) {
  // Helper to format dates cleanly
  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return dateStr;
      return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  // Theme-specific CSS classes
  const fontClass = {
    classic: 'font-serif text-slate-950',
    modern: 'font-sans text-stone-900',
    corporate: 'font-serif text-gray-900',
    tech: 'font-mono text-zinc-900 text-xs sm:text-sm'
  }[theme];

  const headerWeightClass = {
    classic: 'font-semibold border-b border-slate-300 pb-1 mb-2 tracking-wide uppercase text-sm sm:text-base',
    modern: 'font-bold tracking-tight text-stone-950 border-b-2 border-stone-100 pb-1 mb-2 uppercase text-xs sm:text-sm',
    corporate: 'font-medium border-b border-gray-400 pb-0.5 mb-2 uppercase tracking-wider text-xs sm:text-sm',
    tech: 'font-bold border-b border-zinc-200 pb-1 mb-2 text-zinc-950 uppercase text-xs sm:text-sm'
  }[theme];

  const nameSizeClass = {
    classic: 'text-3xl font-bold tracking-wide text-slate-900',
    modern: 'text-3xl font-extrabold tracking-tight text-stone-950',
    corporate: 'text-2xl sm:text-3xl font-semibold tracking-normal text-gray-950',
    tech: 'text-2xl font-bold text-zinc-950 tracking-wider'
  }[theme];

  const titleSizeClass = {
    classic: 'text-lg italic text-slate-700 font-medium',
    modern: 'text-lg font-bold uppercase tracking-wider text-indigo-700',
    corporate: 'text-base font-medium tracking-wide uppercase text-gray-600',
    tech: 'text-sm font-semibold tracking-tight text-amber-700'
  }[theme];

  // Prepare contact elements
  const contactItems = [
    data.email && { id: 'email', val: data.email },
    data.phone && { id: 'phone', val: data.phone },
    data.location && { id: 'location', val: data.location },
    data.website && { id: 'website', val: data.website.replace(/^https?:\/\//, '') },
    data.linkedin && { id: 'linkedin', val: data.linkedin.replace(/^https?:\/\/(www\.)?linkedin\.com\/in\//, 'linkedin.com/in/') },
    data.github && { id: 'github', val: data.github.replace(/^https?:\/\/(www\.)?github\.com\//, 'github.com/') }
  ].filter(Boolean) as { id: string; val: string }[];

  return (
    <div 
      id="printable-resume-page"
      className={`bg-white text-black p-8 sm:p-12 shadow-md w-full min-h-[1056px] mx-auto transition-all ${fontClass}`}
      style={{ contentVisibility: 'auto' }}
    >
      {/* 1. Header Area (Name & Contact) */}
      <div className="text-center mb-6">
        <h1 className={`${nameSizeClass} break-words`} id="resume-head-name">{data.name || 'Your Full Name'}</h1>
        {data.title && (
          <p className={`${titleSizeClass} mt-1`} id="resume-head-title">{data.title}</p>
        )}
        
        {/* Contact list format: clean single-line inline block separated by dots */}
        {contactItems.length > 0 && (
          <div className="flex flex-wrap justify-center items-center gap-x-3 gap-y-1 mt-3 text-xs sm:text-sm text-stone-600 font-normal">
            {contactItems.map((item, index) => (
              <React.Fragment key={item.id}>
                {index > 0 && <span className="text-stone-300 font-sans select-none">•</span>}
                <span className="break-all whitespace-normal">{item.val}</span>
              </React.Fragment>
            ))}
          </div>
        )}
      </div>

      {/* 2. Professional Summary Section */}
      {data.summary && (
        <section className="mb-6" id="resume-section-summary">
          <h2 className={`${headerWeightClass} text-slate-800`}>Professional Summary</h2>
          <p className="text-sm sm:text-base leading-relaxed text-stone-800 whitespace-pre-wrap">{data.summary}</p>
        </section>
      )}

      {/* 3. Core Experience Section */}
      {data.experience && data.experience.length > 0 && (
        <section className="mb-6" id="resume-section-experience">
          <h2 className={`${headerWeightClass} text-slate-800`}>Professional Experience</h2>
          <div className="space-y-4">
            {data.experience.map((exp) => (
              <div key={exp.id} className="text-stone-800">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-baseline mb-1">
                  <div>
                    <strong className="text-sm sm:text-base text-stone-950 font-semibold">{exp.position}</strong>
                    <span className="text-stone-400 font-sans mx-1.5 select-none font-light">|</span>
                    <span className="text-sm sm:text-base font-normal">{exp.company}</span>
                  </div>
                  <div className="text-xs sm:text-sm text-stone-600 font-normal whitespace-nowrap">
                    <span>{formatDate(exp.startDate)}</span>
                    <span className="mx-1 select-none">–</span>
                    <span>{exp.isCurrent ? 'Present' : formatDate(exp.endDate)}</span>
                    {exp.location && <span className="ml-1.5 italic">({exp.location})</span>}
                  </div>
                </div>

                {exp.bullets && exp.bullets.length > 0 && (
                  <ul className="list-disc list-outside pl-5 space-y-1.5 mt-2">
                    {exp.bullets.map((bullet, idx) => (
                      <li key={idx} className="text-xs sm:text-sm leading-relaxed text-stone-700 whitespace-pre-wrap">
                        {bullet}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Skills Section */}
      {data.skills && data.skills.length > 0 && (
        <section className="mb-6" id="resume-section-skills">
          <h2 className={`${headerWeightClass} text-slate-800`}>Core Competencies & Skills</h2>
          <div className="text-xs sm:text-sm leading-relaxed text-stone-800">
            {data.skills.join('  •  ')}
          </div>
        </section>
      )}

      {/* 5. Education Section */}
      {data.education && data.education.length > 0 && (
        <section className="mb-6" id="resume-section-education">
          <h2 className={`${headerWeightClass} text-slate-800`}>Education</h2>
          <div className="space-y-3">
            {data.education.map((edu) => (
              <div key={edu.id} className="text-stone-800">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-baseline mb-0.5">
                  <div>
                    <strong className="text-sm sm:text-base text-stone-950 font-semibold">{edu.degree}{edu.fieldOfStudy ? ` in ${edu.fieldOfStudy}` : ''}</strong>
                    <span className="text-stone-400 font-sans mx-1.5 select-none font-light">|</span>
                    <span className="text-sm sm:text-base font-normal">{edu.institution}</span>
                  </div>
                  <div className="text-xs sm:text-sm text-stone-600 font-normal whitespace-nowrap">
                    <span>{edu.startDate}</span>
                    {edu.endDate && (
                      <>
                        <span className="mx-1 select-none">–</span>
                        <span>{edu.endDate}</span>
                      </>
                    )}
                    {edu.location && <span className="ml-1.5 italic">({edu.location})</span>}
                  </div>
                </div>
                {edu.gpa && (
                  <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
                    <strong>GPA:</strong> {edu.gpa}
                  </p>
                )}
                {edu.description && (
                  <p className="text-xs sm:text-sm text-stone-600 mt-1 whitespace-pre-wrap">
                    {edu.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Certifications Section */}
      {data.certifications && data.certifications.length > 0 && (
        <section id="resume-section-certifications">
          <h2 className={`${headerWeightClass} text-slate-800`}>Certifications</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5">
            {data.certifications.map((cert) => (
              <div key={cert.id} className="text-xs sm:text-sm flex justify-between items-baseline text-stone-800">
                <div>
                  <strong className="font-semibold text-stone-950">{cert.name}</strong>
                  {cert.issuer && <span className="text-stone-600"> – {cert.issuer}</span>}
                </div>
                {cert.date && (
                  <span className="text-xs text-stone-500 font-mono whitespace-nowrap ml-2">
                    {formatDate(cert.date)}
                  </span>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Print-specific structural style to ensure formatting isn't broken */}
      <style>{`
        @media print {
          body {
            background: white !important;
            color: black !important;
          }
          #printable-resume-page {
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            min-height: auto !important;
          }
        }
      `}</style>
    </div>
  );
}
