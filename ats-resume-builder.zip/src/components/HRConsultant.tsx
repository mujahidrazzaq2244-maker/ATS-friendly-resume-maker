import { useState } from 'react';
import { ResumeData, AIScoreResult } from '../types';
import { 
  Sparkles, 
  CheckCircle, 
  AlertCircle, 
  TrendingUp, 
  Award, 
  Tag, 
  RotateCcw,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Zap,
  Loader2
} from 'lucide-react';

interface HRConsultantProps {
  data: ResumeData;
  onGetScore: () => Promise<AIScoreResult | null>;
  scoreResult: AIScoreResult | null;
  loadingScore: boolean;
  scoreError: string | null;
  onApplyKeywords: (keywords: string[]) => void;
}

export default function HRConsultant({
  data,
  onGetScore,
  scoreResult,
  loadingScore,
  scoreError,
  onApplyKeywords
}: HRConsultantProps) {
  const [copiedKeyword, setCopiedKeyword] = useState<string | null>(null);

  // Helper for scoring circle background
  const getScoreColor = (score: number) => {
    if (score >= 85) return { text: 'text-emerald-600', border: 'border-emerald-500', bg: 'bg-emerald-50' };
    if (score >= 70) return { text: 'text-amber-600', border: 'border-amber-500', bg: 'bg-amber-50' };
    return { text: 'text-red-600', border: 'border-red-500', bg: 'bg-red-50' };
  };

  const handleCopyAndAddKeyword = (keyword: string) => {
    onApplyKeywords([keyword]);
    setCopiedKeyword(keyword);
    setTimeout(() => setCopiedKeyword(null), 1500);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-stone-100 p-6 space-y-6" id="consultant-panel-root">
      
      {/* Introduction Badge */}
      <div className="flex items-start gap-4 bg-gradient-to-r from-amber-50 to-orange-50 p-4 rounded-xl border border-amber-100/50">
        <div className="bg-amber-100 p-2 rounded-lg text-amber-800 shrink-0">
          <Sparkles size={20} />
        </div>
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-amber-900 flex items-center gap-1.5">
            Expert HR ATS Consulting Desk
          </h3>
          <p className="text-xs text-amber-800 leading-relaxed">
            I am your expert HR Executive and Recruitment Consultant. I evaluate resumes against modern corporate database filters, checking for STAR impact statements, metrics usage, logical layouts, and keyword density.
          </p>
        </div>
      </div>

      {/* Main Action Trigger */}
      <div className="text-center py-4">
        <button
          type="button"
          disabled={loadingScore}
          onClick={onGetScore}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-stone-900 text-white hover:bg-black font-bold text-sm px-6 py-3 rounded-lg shadow-sm hover:shadow transition-all disabled:opacity-60 cursor-pointer"
        >
          {loadingScore ? (
            <>
              <Loader2 className="animate-spin" size={16} />
              AI HR Executive is analyzing your resume...
            </>
          ) : (
            <>
              <TrendingUp size={16} />
              {scoreResult ? 'Analyze & Re-Score Resume' : 'Analyze Resume & Calculate ATS Score'}
            </>
          )}
        </button>
        {scoreError && (
          <p className="text-xs text-red-500 mt-2 font-medium flex items-center justify-center gap-1">
            <AlertCircle size={13} />
            {scoreError}
          </p>
        )}
      </div>

      {/* Loading state placeholders */}
      {loadingScore && (
        <div className="space-y-4 animate-pulse">
          <div className="h-28 bg-stone-50 rounded-xl border border-stone-100 p-4 flex gap-4 items-center">
            <div className="w-16 h-16 rounded-full bg-stone-200"></div>
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-stone-200 rounded w-1/3"></div>
              <div className="h-3 bg-stone-200 rounded w-3/4"></div>
            </div>
          </div>
          <div className="h-32 bg-stone-50 rounded-xl border border-stone-100"></div>
        </div>
      )}

      {/* Score Results Display */}
      {scoreResult && !loadingScore && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Main score metrics card */}
          <div className="flex flex-col sm:flex-row gap-5 items-center bg-stone-50 p-5 rounded-xl border border-stone-200/60">
            {/* Circular score gauge */}
            <div className={`w-20 h-20 sm:w-24 sm:h-24 rounded-full border-4 flex flex-col items-center justify-center font-bold ${getScoreColor(scoreResult.score).border} ${getScoreColor(scoreResult.score).bg} shrink-0 shadow-inner`}>
              <span className={`text-2xl sm:text-3xl ${getScoreColor(scoreResult.score).text}`}>{scoreResult.score}</span>
              <span className="text-[10px] text-stone-500 font-mono tracking-tight -mt-0.5">/ 100</span>
            </div>

            <div className="space-y-1.5 text-center sm:text-left">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="text-sm font-semibold text-stone-500 uppercase tracking-wide">Overall Rating:</span>
                <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                  scoreResult.rating === 'Excellent' 
                    ? 'bg-emerald-100 text-emerald-800' 
                    : scoreResult.rating === 'Good' 
                      ? 'bg-amber-100 text-amber-800' 
                      : 'bg-red-100 text-red-800'
                }`}>
                  {scoreResult.rating}
                </span>
              </div>
              <h4 className="text-sm font-bold text-stone-900">Quantifiable Metrics Diagnostic</h4>
              <p className="text-xs text-stone-600 leading-normal">
                {scoreResult.metricsCheck}
              </p>
            </div>
          </div>

          {/* Core breakdown columns */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Strengths Column */}
            <div className="p-4 border border-stone-150 rounded-xl space-y-3">
              <h5 className="text-xs font-bold text-stone-500 uppercase tracking-widest flex items-center gap-1.5">
                <CheckCircle className="text-emerald-500 shrink-0" size={14} />
                Detected Strengths
              </h5>
              <ul className="space-y-2">
                {scoreResult.strengths.map((str, idx) => (
                  <li key={idx} className="text-xs text-stone-700 font-normal leading-relaxed flex items-start gap-2">
                    <span className="text-emerald-500 select-none font-bold mt-0.5">✓</span>
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Improvements Column */}
            <div className="p-4 border border-stone-150 rounded-xl space-y-3">
              <h5 className="text-xs font-bold text-stone-500 uppercase tracking-widest flex items-center gap-1.5">
                <AlertCircle className="text-amber-500 shrink-0" size={14} />
                Strategic Improvements Needed
              </h5>
              <ul className="space-y-2">
                {scoreResult.improvements.map((imp, idx) => (
                  <li key={idx} className="text-xs text-stone-700 font-normal leading-relaxed flex items-start gap-2">
                    <span className="text-amber-500 select-none font-bold mt-0.5">→</span>
                    <span>{imp}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* ATS Keyword Booster Panel */}
          {scoreResult.atsKeywords && scoreResult.atsKeywords.length > 0 && (
            <div className="p-5 border border-amber-200/60 bg-amber-50/20 rounded-xl space-y-3">
              <h5 className="text-xs font-bold text-amber-900 uppercase tracking-widest flex items-center gap-1.5">
                <Tag className="text-amber-700 shrink-0" size={14} />
                ATS Keyword Density Injector
              </h5>
              <p className="text-xs text-stone-600 leading-relaxed">
                Applicant tracking systems search for direct phrase matches. Click any recommended keyword to immediately append/inject it to your Core Skills:
              </p>
              
              <div className="flex flex-wrap gap-1.5 pt-1">
                {scoreResult.atsKeywords.map((kw, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleCopyAndAddKeyword(kw)}
                    className="group flex items-center gap-1 text-xs font-medium bg-white text-stone-700 hover:text-amber-950 border border-stone-200 hover:border-amber-400 hover:bg-amber-50/50 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer"
                  >
                    <span>+ {kw}</span>
                    <span className="text-[10px] text-stone-400 group-hover:text-amber-700">
                      {copiedKeyword === kw ? 'Added!' : 'Add'}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Core ATS Constraints Checklist */}
          <div className="p-4 border border-stone-100 bg-stone-50 rounded-xl space-y-3">
            <h5 className="text-xs font-bold text-stone-500 uppercase tracking-widest flex items-center gap-1.5">
              <ShieldCheck className="text-stone-700 shrink-0" size={14} />
              ATS System Requirements Check
            </h5>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-stone-700">
              <div className="flex items-center gap-2">
                <CheckCircle className="text-emerald-500 shrink-0" size={14} />
                <span>Single-Column Layout (Enforced)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="text-emerald-500 shrink-0" size={14} />
                <span>Standard Section Headers (Education, Experience)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="text-emerald-500 shrink-0" size={14} />
                <span>No complex tables or headers (ATS-friendly)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="text-emerald-500 shrink-0" size={14} />
                <span>Standard Contact separators (• block)</span>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* Blank slate / call-to-action */}
      {!scoreResult && !loadingScore && (
        <div className="text-center py-8 border border-dashed border-stone-200 rounded-xl bg-stone-50/30">
          <BookOpen className="mx-auto text-stone-300 mb-2" size={32} />
          <p className="text-xs text-stone-500 max-w-sm mx-auto leading-relaxed">
            Click <strong>Analyze Resume</strong> to inspect and evaluate your resume sections. The expert AI HR controller will gauge your draft, flag improvements, and recommend optimal corporate tags.
          </p>
        </div>
      )}

    </div>
  );
}
