export interface Education {
  id: string;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate: string;
  location: string;
  gpa?: string;
  description?: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  location: string;
  isCurrent: boolean;
  bullets: string[];
}

export interface Certifications {
  id: string;
  name: string;
  issuer: string;
  date: string;
  url?: string;
}

export interface ResumeData {
  name: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  website: string;
  linkedin: string;
  github: string;
  summary: string;
  education: Education[];
  experience: Experience[];
  skills: string[];
  certifications: Certifications[];
}

export interface AIScoreResult {
  score: number;
  rating: 'Needs Improvement' | 'Good' | 'Excellent';
  strengths: string[];
  improvements: string[];
  atsKeywords: string[];
  metricsCheck: string;
}
