import { useState, useTransition } from 'react';
import { ResumeData, AIScoreResult } from './types';
import { RESUME_PRESETS } from './data/presets';
import ResumeForm from './components/ResumeForm';
import ResumePreview from './components/ResumePreview';
import HRConsultant from './components/HRConsultant';
import { 
  Sparkles, 
  Printer, 
  FileText, 
  Sliders, 
  UserCheck, 
  Award,
  HelpCircle,
  Lightbulb,
  CheckCircle,
  FileDown,
  ChevronDown
} from 'lucide-react';

export default function App() {
  const [resumeData, setResumeData] = useState<ResumeData>(RESUME_PRESETS.softwareEngineer.data);
  const [resumeTheme, setResumeTheme] = useState<'classic' | 'modern' | 'corporate' | 'tech'>('modern');
  const [activeTab, setActiveTab] = useState<'details' | 'ai-consultant' | 'ats-tips'>('details');
  const [dropdownOpen, setDropdownOpen] = useState(false);

  // AI-related loading and feedback states managed via standard hook architecture
  const [scoreResult, setScoreResult] = useState<AIScoreResult | null>(null);
  const [loadingScore, setLoadingScore] = useState(false);
  const [scoreError, setScoreError] = useState<string | null>(null);
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [loadingBulletId, setLoadingBulletId] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  // Load a preset example portfolio
  const handlePresetLoad = (presetKey: string) => {
    startTransition(() => {
      setResumeData(RESUME_PRESETS[presetKey].data);
      setScoreResult(null); // Clear previous score to guarantee freshness
      setDropdownOpen(false);
    });
  };

  // 1. API: Analyze & Score Resume
  const handleGetScore = async (): Promise<AIScoreResult | null> => {
    setLoadingScore(true);
    setScoreError(null);
    try {
      const response = await fetch('/api/resume/score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(resumeData)
      });
      if (!response.ok) {
        throw new Error('Could not calculate score. Please verify server connection.');
      }
      const data: AIScoreResult = await response.json();
      setScoreResult(data);
      return data;
    } catch (err: any) {
      setScoreError(err.message || 'An error occurred during resume evaluation');
      return null;
    } finally {
      setLoadingScore(false);
    }
  };

  // 2. API: Improve Profile Summary
  const handleImproveSummary = async (currentSummary: string) => {
    setLoadingSummary(true);
    try {
      const response = await fetch('/api/resume/improve-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          summary: currentSummary,
          title: resumeData.title,
          skills: resumeData.skills
        })
      });
      if (!response.ok) {
        throw new Error('Could not polish summary');
      }
      const data = await response.json();
      if (data.improved) {
        setResumeData(prev => ({ ...prev, summary: data.improved }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingSummary(false);
    }
  };

  // 3. API: Refine Experience Bullet with STAR structure
  const handleRefineBullet = async (expIndex: number, bulletIndex: number, currentBullet: string, position: string, company: string) => {
    const customId = `${expIndex}-${bulletIndex}`;
    setLoadingBulletId(customId);
    try {
      const response = await fetch('/api/resume/refine-bullet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bullet: currentBullet,
          position,
          company
        })
      });
      if (!response.ok) {
        throw new Error('Could not refine bullet point');
      }
      const data = await response.json();
      if (data.optimized) {
        const updatedExp = [...resumeData.experience];
        const updatedBullets = [...updatedExp[expIndex].bullets];
        updatedBullets[bulletIndex] = data.optimized;
        updatedExp[expIndex].bullets = updatedBullets;
        setResumeData(prev => ({ ...prev, experience: updatedExp }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingBulletId(null);
    }
  };

  // Append AI recommendations directly to skills array
  const handleApplyKeywords = (keywords: string[]) => {
    const updatedSkills = [...resumeData.skills];
    keywords.forEach(kw => {
      if (!updatedSkills.includes(kw)) {
        updatedSkills.push(kw);
      }
    });
    setResumeData(prev => ({ ...prev, skills: updatedSkills }));
  };

  // Trigger browser print window cleanly
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col font-sans selection:bg-amber-100 selection:text-amber-900" id="app-root">
      
      {/* Visual Navigation Bar */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-50 print:hidden" id="app-header-nav">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          
          {/* App Brand */}
          <div className="flex items-center gap-2">
            <div className="bg-amber-600 text-white p-2 rounded-lg">
              <FileText size={20} />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-bold text-stone-900 leading-tight">ATS Resume Builder</h1>
              <p className="text-[10px] sm:text-xs text-stone-500 font-medium">Expert HR Manager Assistant</p>
            </div>
          </div>

          {/* Quick Preset Selector & Printing Actions */}
          <div className="flex items-center gap-3">
            
            {/* Quick Presets Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-semibold text-stone-700 hover:text-stone-900 bg-stone-50 hover:bg-stone-100 rounded-lg border border-stone-200 cursor-pointer transition-colors"
                id="preset-dropdown-btn"
              >
                <span>Example Templates</span>
                <ChevronDown size={14} className={`transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {dropdownOpen && (
                <div className="absolute right-0 mt-1.5 w-56 bg-white border border-stone-100 rounded-xl shadow-lg ring-1 ring-black/5 divide-y divide-stone-50 z-50 animate-fade-in" id="preset-list-dropdown">
                  <div className="p-1">
                    {Object.entries(RESUME_PRESETS).map(([key, item]) => (
                      <button
                        key={key}
                        onClick={() => handlePresetLoad(key)}
                        className="w-full text-left px-3 py-2 text-xs sm:text-sm text-stone-700 hover:text-stone-950 hover:bg-stone-50 rounded-lg transition-colors font-medium flex items-center justify-between cursor-pointer"
                      >
                        <span>{item.label}</span>
                        {resumeData.title === item.data.title && <CheckCircle size={14} className="text-emerald-500" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Print/Download Button */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm px-4 py-2 rounded-lg shadow-sm hover:shadow transition-all cursor-pointer"
            >
              <Printer size={15} />
              <span className="hidden sm:inline">Export / Save PDF</span>
              <span className="sm:hidden">PDF/Print</span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Workspace split */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 print:p-0 print:-mt-16" id="workspace-grid">
        
        {/* Left Hand: Editors, AI tools and Guides (Grabs 5 columns on desktop) */}
        <div className="lg:col-span-12 xl:col-span-5 flex flex-col gap-6 print:hidden" id="left-workspace-panel">
          
          {/* Main workspace control switches */}
          <div className="bg-white border border-stone-200 rounded-xl p-1 flex shadow-sm">
            <button
              onClick={() => setActiveTab('details')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'details' 
                  ? 'bg-stone-900 text-white shadow-sm' 
                  : 'text-stone-600 hover:text-stone-950'
              }`}
            >
              <Sliders size={15} />
              Resume Editor
            </button>
            
            <button
              onClick={() => setActiveTab('ai-consultant')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'ai-consultant' 
                  ? 'bg-stone-900 text-white shadow-sm' 
                  : 'text-stone-600 hover:text-stone-950'
              }`}
            >
              <Sparkles size={15} className="text-amber-500" />
              AI HR Score Panel
            </button>

            <button
              onClick={() => setActiveTab('ats-tips')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'ats-tips' 
                  ? 'bg-stone-900 text-white shadow-sm' 
                  : 'text-stone-600 hover:text-stone-950'
              }`}
            >
              <HelpCircle size={15} />
              ATS Guidelines
            </button>
          </div>

          {/* ACTIVE CONTENT DRIVER */}
          <div className="flex-1">
            {activeTab === 'details' && (
              <ResumeForm
                data={resumeData}
                onChange={setResumeData}
                onImproveSummary={handleImproveSummary}
                onRefineBullet={handleRefineBullet}
                loadingSummary={loadingSummary}
                loadingBulletId={loadingBulletId}
              />
            )}

            {activeTab === 'ai-consultant' && (
              <HRConsultant
                data={resumeData}
                onGetScore={handleGetScore}
                scoreResult={scoreResult}
                loadingScore={loadingScore}
                scoreError={scoreError}
                onApplyKeywords={handleApplyKeywords}
              />
            )}

            {activeTab === 'ats-tips' && (
              <div className="bg-white rounded-xl shadow-sm border border-stone-200 p-6 space-y-6" id="ats-tips-container">
                <h3 className="text-lg font-bold text-stone-900 flex items-center gap-1.5 border-b border-stone-100 pb-2">
                  <Lightbulb className="text-amber-600" size={18} />
                  What Makes a Resume ATS-Friendly?
                </h3>

                <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                  ATS systems parse text from left to right. When resumes fail to parse, you are automatically filtered out. Applying standard layouts and text formatting ensures your record enters the recruiter's system cleanly.
                </p>

                <div className="space-y-4 pt-1">
                  <div className="flex items-start gap-3">
                    <div className="bg-emerald-50 text-emerald-800 p-1.5 rounded-lg shrink-0">
                      <CheckCircle size={14} />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-stone-900">Standard Heading Structure</h4>
                      <p className="text-[11px] sm:text-xs text-stone-500 leading-normal">
                        Use common sections name like "Education", "Professional Experience" instead of unusual synonyms such as "Scholastic Background".
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="bg-emerald-50 text-emerald-800 p-1.5 rounded-lg shrink-0">
                      <CheckCircle size={14} />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-stone-900">Single-Column Flow</h4>
                      <p className="text-[11px] sm:text-xs text-stone-500 leading-normal">
                        Avoid multi-column tables, floating text boxes, or columns. ATS text readers ignore visual placements and merge side-by-side texts into scrambled phrases.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="bg-emerald-50 text-emerald-800 p-1.5 rounded-lg shrink-0">
                      <CheckCircle size={14} />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-stone-900">Quantified Impact (STAR method)</h4>
                      <p className="text-[11px] sm:text-xs text-stone-500 leading-normal">
                        Modern screening processes search for performance phrases. Instead of stating "Responsible for managing marketing database," write "Managed marketing database of 15,000 corporate records, increasing segment targeting by 14%".
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="bg-emerald-50 text-emerald-800 p-1.5 rounded-lg shrink-0">
                      <CheckCircle size={14} />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-stone-900">Keyword Density</h4>
                      <p className="text-[11px] sm:text-xs text-stone-500 leading-normal">
                        Make sure the precise vocabulary of high-demand tasks (e.g., "RESTful APIs", "A/B Testing", "SHRM") is clearly written in your skills list.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-stone-50 border border-stone-100 rounded-lg text-xs leading-normal text-stone-600">
                  <strong>Save PDF Instruction:</strong> When exporting to PDF, ensure your browser print properties are set with <strong>no headers and footers</strong> and option <strong>background graphics enabled</strong>. Select "Save as PDF" to save a local physical copy.
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Hand: LIVE ATS Page Preview (Grabs 7 columns on desktop) */}
        <div className="lg:col-span-12 xl:col-span-7 flex flex-col gap-4 print:w-full print:p-0 print:col-span-12" id="right-workspace-panel">
          
          {/* Theme selector bar */}
          <div className="bg-white border border-stone-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-sm print:hidden">
            <span className="text-xs font-bold text-stone-500 uppercase tracking-widest">Select ATS typography style:</span>
            
            <div className="flex gap-1">
              {(['classic', 'modern', 'corporate', 'tech'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setResumeTheme(t)}
                  className={`px-3 py-1.5 text-xs font-semibold capitalize rounded-lg border cursor-pointer transition-all ${
                    resumeTheme === t
                      ? 'bg-amber-600 text-white border-amber-500 shadow-sm'
                      : 'bg-white hover:bg-stone-50 text-stone-700 border-stone-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Actual Resume Sheet Paper Previewer */}
          <div className="bg-stone-200/50 rounded-xl p-4 sm:p-6 border border-stone-300/40 print:bg-white print:p-0 print:border-none" id="preview-outer-container">
            <ResumePreview data={resumeData} theme={resumeTheme} />
          </div>

        </div>

      </main>

      {/* Small informative Footer */}
      <footer className="bg-white border-t border-stone-200 py-4 text-center mt-auto print:hidden" id="app-footer-bar">
        <p className="text-xs text-stone-400 font-medium">
          Expert HR Manager ATS Assistant • Single Column Layout & Multi-Format Exports Enforced.
        </p>
      </footer>
    </div>
  );
}

