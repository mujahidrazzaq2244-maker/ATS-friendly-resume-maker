import { ResumeData } from '../types';

export const RESUME_PRESETS: Record<string, { label: string; data: ResumeData }> = {
  softwareEngineer: {
    label: 'Software Engineer',
    data: {
      name: 'Sarah Jenkins',
      title: 'Senior Software Engineer',
      email: 'sarah.jenkins@email.com',
      phone: '(555) 123-4567',
      location: 'San Francisco, CA',
      website: 'https://sarahjenkins.dev',
      linkedin: 'https://linkedin.com/in/sarahjenkins-dev',
      github: 'https://github.com/sarahj',
      summary: 'Dynamic Senior Software Engineer with 6+ years of experience designing and implementing scalable cloud applications. Proven track record of optimizing database queries to reduce latency and leading cross-functional teams to deliver critical web initiatives. Specialized in React, TypeScript, Node.js, and AWS deployments.',
      education: [
        {
          id: 'edu-1',
          institution: 'University of California, Berkeley',
          degree: 'Bachelor of Science',
          fieldOfStudy: 'Computer Science',
          startDate: '2016',
          endDate: '2020',
          location: 'Berkeley, CA',
          gpa: '3.82',
          description: 'Graduated with Honors. Teaching Assistant for Database Systems and Data Structures courses.'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          company: 'CloudScale Technologies',
          position: 'Senior Software Engineer',
          startDate: '2022-06',
          endDate: 'Present',
          location: 'San Francisco, CA',
          isCurrent: true,
          bullets: [
            'Architected microservices-based file streaming pipeline using Node.js and AWS S3, improving file upload throughput by 42%.',
            'Led a team of 4 engineers to migrate legacy React application to TypeScript and Vite, decreasing build times by 65%.',
            'Implemented Redis caching layer that reduced main database load by 30% and decreased average API response time under peak load from 450ms to 90ms.',
            'Mentored 3 junior developers through regular pair programming sessions and structured code reviews.'
          ]
        },
        {
          id: 'exp-2',
          company: 'LaunchPad Systems',
          position: 'Software Engineer II',
          startDate: '2020-08',
          endDate: '2022-05',
          location: 'Oakland, CA',
          isCurrent: false,
          bullets: [
            'Developed and polished 12+ highly-interactive data visualization dashboards using React and D3.js, boosting customer engagement by 18%.',
            'Designed and integrated RESTful APIs with Express, serving over 500,000 requests daily with 99.98% uptime.',
            'Collaborated with product managers to implement automated testing pipelines via GitHub Actions, reducing bug leakage into production by 24%.'
          ]
        }
      ],
      skills: [
        'React',
        'TypeScript',
        'Node.js',
        'Python',
        'Express',
        'PostgreSQL',
        'MongoDB',
        'AWS (S3, EC2, Lambda)',
        'Docker',
        'RESTful APIs',
        'Git & GitHub Actions',
        'D3.js',
        'System Architecture'
      ],
      certifications: [
        {
          id: 'cert-1',
          name: 'AWS Certified Solutions Architect – Associate',
          issuer: 'Amazon Web Services',
          date: '2023-04'
        },
        {
          id: 'cert-2',
          name: 'Professional Scrum Master I (PSM I)',
          issuer: 'Scrum.org',
          date: '2021-11'
        }
      ]
    }
  },
  marketingSpecialist: {
    label: 'Marketing Manager',
    data: {
      name: 'Marcus Vance',
      title: 'Digital Marketing Manager',
      email: 'marcus.vance@marketing.com',
      phone: '(555) 987-6543',
      location: 'Austin, TX',
      website: 'https://marcusvance.co',
      linkedin: 'https://linkedin.com/in/marcusvance-mktg',
      github: '',
      summary: 'Data-driven Digital Marketing Professional with 5+ years of experience leading multichat campaigns, paid advertisements, and brand positioning strategies. Highly skilled at utilizing analytical metrics to drive organic traffic, reduce customer acquisition cost (CAC), and maximize return on ad spend (ROAS).',
      education: [
        {
          id: 'edu-2',
          institution: 'University of Texas at Austin',
          degree: 'Bachelor of Business Administration',
          fieldOfStudy: 'Marketing',
          startDate: '2015',
          endDate: '2019',
          location: 'Austin, TX',
          gpa: '3.65',
          description: 'Executive Director of UT Marketing Association. Mini-thesis on Consumer Sentiment Models.'
        }
      ],
      experience: [
        {
          id: 'exp-3',
          company: 'Apex Digital Growth',
          position: 'Digital Marketing Manager',
          startDate: '2021-09',
          endDate: 'Present',
          location: 'Austin, TX',
          isCurrent: true,
          bullets: [
            'Formulated and executed digital advertising strategies on Google & Meta with an annual budget of $120k, delivering a sustained 4.2x ROAS.',
            'Optimized organic search presence through advanced SEO adjustments and keyword targeting, increasing overall monthly blog traffic by 140% over 12 months.',
            'Supervised email marketing funnel redesign that boosted open rates by 22% and increased direct conversions by $45,000 in quarterly revenue.',
            'Collaborated with design and engineering teams to model high-converting landing pages, improving opt-in conversions from 3.5% to 8.2%.'
          ]
        },
        {
          id: 'exp-4',
          company: 'BrightStar Brand Collective',
          position: 'Marketing Generalist',
          startDate: '2019-06',
          endDate: '2021-08',
          location: 'Dallas, TX',
          isCurrent: false,
          bullets: [
            'Coordinated visual asset creations and content schedules across 5 major social channels, expanding organic follower base by 35% in 6 months.',
            'Conducted weekly competitive analyses using SEMrush to uncover high-opportunity keywords for the client services pipeline.',
            'Assisted in planning over 15 digital product launch webinars, averaging 1,200 concurrent viewers and 15% conversion to paid plans.'
          ]
        }
      ],
      skills: [
        'Search Engine Optimization (SEO)',
        'Pay-Per-Click Advertising (PPC)',
        'Google Analytics 4',
        'Meta Ads Manager',
        'HubSpot & Mailchimp',
        'Copywriting',
        'Conversion Rate Optimization (CRO)',
        'Content Strategy',
        'SEMrush / Ahrefs',
        'A/B Testing',
        'Budget Allocation',
        'Customer Journey Mapping'
      ],
      certifications: [
        {
          id: 'cert-3',
          name: 'Google Analytics Individual Qualification (GAIQ)',
          issuer: 'Google',
          date: '2024-01'
        },
        {
          id: 'cert-4',
          name: 'Inbound Marketing Certification',
          issuer: 'HubSpot Academy',
          date: '2022-07'
        }
      ]
    }
  },
  hrManager: {
    label: 'HR Specialist',
    data: {
      name: 'Elena Rostova',
      title: 'Senior Talent Acquisition Specialist',
      email: 'elena.rostova@hrpro.com',
      phone: '(555) 753-1590',
      location: 'Chicago, IL',
      website: '',
      linkedin: 'https://linkedin.com/in/elena-rostova-hr',
      github: '',
      summary: 'Results-oriented Senior Human Resources & Talent Professional with 7+ years of experience leading full-cycle recruiting drives, training initiatives, and retention programs. Expert in designing structured onboarding experiences that reduce early attrition of key hires and leveraging ATS systems to streamline the candidate intake funnel.',
      education: [
        {
          id: 'edu-3',
          institution: 'Northwestern University',
          degree: 'Master of Science',
          fieldOfStudy: 'Human Resources Management',
          startDate: '2016',
          endDate: '2018',
          location: 'Evanston, IL',
          gpa: '3.90',
          description: 'Specialization in Strategic HR Alignment and Organizational Behavior.'
        },
        {
          id: 'edu-4',
          institution: 'DePaul University',
          degree: 'Bachelor of Arts',
          fieldOfStudy: 'Psychology',
          startDate: '2012',
          endDate: '2016',
          location: 'Chicago, IL',
          gpa: '3.70'
        }
      ],
      experience: [
        {
          id: 'exp-5',
          company: 'Apex Recruiting Partners',
          position: 'Senior Talent Acquisition Specialist',
          startDate: '2021-03',
          endDate: 'Present',
          location: 'Chicago, IL',
          isCurrent: true,
          bullets: [
            'Managed full-cycle recruitment pipeline to support 150+ corporate hires annually across engineering, marketing, and product verticals.',
            'Redesigned the applicant tracking system (ATS) workflow, cutting the average time-to-hire metric from 45 days down to 28 days.',
            'Designed active sourcing programs targeting diverse channels, resulting in a 35% increase in highly qualified underrepresented candidates in the final round.',
            'Pioneered candidate feedback survey protocols, achieving a 94% positive rating for overall interview experience.'
          ]
        },
        {
          id: 'exp-6',
          company: 'Midwest Financial Group',
          position: 'HR Specialist',
          startDate: '2018-07',
          endDate: '2021-02',
          location: 'Chicago, IL',
          isCurrent: false,
          bullets: [
            'Created an interactive, automated remote onboarding program that improved 90-day retention rates by 18% during key corporate restructures.',
            'Hosted bi-weekly professional development and alignment seminars for 40+ corporate middle managers.',
            'Managed employment compliance tracking and internal HR logs, maintaining zero historical errors through consecutive external audits.'
          ]
        }
      ],
      skills: [
        'Full-Cycle Recruiting',
        'Applicant Tracking Systems (ATS)',
        'Candidate Experience Design',
        'Strategic Sourcing',
        'HR Compliance',
        'Onboarding & Integration',
        'Interviewing Frameworks',
        'Conflict Management',
        'LinkedIn Recruiter',
        'Workday & Greenhouse',
        'Data-Driven Decision Making',
        'Performance Management'
      ],
      certifications: [
        {
          id: 'cert-5',
          name: 'SHRM Certified Professional (SHRM-CP)',
          issuer: 'Society for Human Resource Management',
          date: '2022-06'
        }
      ]
    }
  }
};
